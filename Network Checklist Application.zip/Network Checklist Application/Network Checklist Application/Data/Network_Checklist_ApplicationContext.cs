﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Network_Checklist_Application.Models;

namespace Network_Checklist_Application.Data
{
    public class Network_Checklist_ApplicationContext : DbContext
    {
        public Network_Checklist_ApplicationContext()
        {
        }

        public Network_Checklist_ApplicationContext (DbContextOptions<Network_Checklist_ApplicationContext> options)
            : base(options)
        {
        }

        public DbSet<Network_Checklist_Application.Models.Checklist> Checklist { get; set; } = default!;
        public virtual DbSet<Login> Login { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=MENTAIN\\SQLEXPRESS;Initial Catalog=ChecklistDB;Integrated Security=True;TrustServerCertificate=True");
            }
        }


    }
   
}
