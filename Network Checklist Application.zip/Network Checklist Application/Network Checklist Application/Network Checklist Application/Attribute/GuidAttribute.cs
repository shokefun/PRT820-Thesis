﻿using System.ComponentModel.DataAnnotations;

namespace Network_Checklist_Application.Attribute
{
    public class GuidAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (value is Guid guid)
            {
                // Check if the GUID is not equal to the default empty GUID
                return guid != Guid.Empty;
            }

            return false; // Property is not a GUID
        }
    }
}
