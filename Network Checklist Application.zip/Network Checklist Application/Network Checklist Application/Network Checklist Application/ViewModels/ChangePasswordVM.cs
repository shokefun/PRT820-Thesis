﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Network_Checklist_Application.ViewModels
{
    [NotMapped]
    public class ChangePasswordVM
    {
        [Required]
        [Display(Name ="Current Password")]
        public string CurrentPassword { get; set; }
        [Required]
        [Display(Name = "New Password")]
        public string NewPassword { get; set; }
    }
}
