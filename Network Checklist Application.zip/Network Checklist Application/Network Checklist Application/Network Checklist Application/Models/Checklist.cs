﻿
using Microsoft.AspNetCore.Mvc.Rendering;
using Network_Checklist_Application.ViewModels;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Network_Checklist_Application.Models
{
    public class Checklist
    {
        public Checklist()
        {
          Dropdown1 = new List<Itemlist>() {
        new Itemlist { Text = "Network Performance Assessment", Value = "Network Performance Assessment" },
        
        };
            Dropdown02 = new List<Itemlist>() {
        new Itemlist { Text = "Data Transfer Optimization", Value = "Data Transfer Optimization" },

        };
            Dropdown2 = new List<Itemlist>() {
        new Itemlist { Text = "High", Value = "High" },
        new Itemlist { Text = "Medium", Value = "Medium" },
        new Itemlist { Text = "Low", Value = "Low" }

        };
            Dropdown3 = new List<Itemlist>() {
        new Itemlist { Text = "Yes", Value = "Yes" },
        new Itemlist { Text = "In Progress", Value = "In Progress" },
        new Itemlist { Text = "No", Value = "No" }

        };
        }
    
        //*************************** Model*****************************
        public int Id { get; set; }
     
        public string Task { get; set; }


       

        public string TaskDone { get; set; }
       
        public string StaffName { get; set; }
        public string LineManager { get; set; }
        public string Priority { get; set; }
        [DataType(DataType.Date)]
        public DateTime DueDate { get; set; }
        [DataType(DataType.Date)]
        public DateTime DateCompleted { get; set; }
        public string Comment { get; set; }

        //****************dropped down list*************************

        [NotMapped]
        public List<Itemlist> Dropdown1 { get; set; }
        [NotMapped]
        public List<Itemlist> Dropdown02 { get; set; }
        [NotMapped]
        public List<Itemlist> Dropdown2 { get; set; }
        [NotMapped]
        public List<Itemlist> Dropdown3 { get; set; }

    }
    [NotMapped]
    public class Itemlist
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }
}
