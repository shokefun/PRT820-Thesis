﻿
using System;
using System.ComponentModel.DataAnnotations;

namespace Network_Checklist_Application.Models
{
    public class Checklist
    {

        public int Id { get; set; }
     
        public string Task { get; set; }
        public string TaskDone { get; set; }
        public string ActionTaken { get; set; }
        public string StaffName { get; set; }
        public string LineManager { get; set; }
        public string Priority { get; set; }
        [DataType(DataType.Date)]
        public DateTime DueDate { get; set; }
        [DataType(DataType.Date)]
        public DateTime DateCompleted { get; set; }
        public string Comment { get; set; }



       
    }
}
