﻿
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Mvc.Rendering;
using Network_Checklist_Application.ViewModels;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Reflection.PortableExecutable;

namespace Network_Checklist_Application.Models
{
    public class Checklist
    {
        public Checklist()
        {
          Dropdown1 = new List<Itemlist>() {
        new Itemlist { Text = "Network Performance Assessment", Value = "Network Performance Assessment" },
        
        };
            Dropdown02 = new List<Itemlist>() {
        new Itemlist { Text = "Data Transfer Optimization", Value = "Data Transfer Optimization" },

        };
            Dropdown03 = new List<Itemlist>() {
        new Itemlist { Text = "Redundancy and Failover", Value = "Redundancy and Failover" },

        };
            Dropdown04 = new List<Itemlist>() {
        new Itemlist { Text = "Load Balancing and Scalability", Value = "Load Balancing and Scalability" },

        };
            Dropdown05 = new List<Itemlist>() {
        new Itemlist { Text = "Caching and Content Delivery Networks", Value = "Caching and Content Delivery Networks" },

        };
            Dropdown06 = new List<Itemlist>() {
        new Itemlist { Text = "Network Security", Value = "Network Security" },

        };
            Dropdown07 = new List<Itemlist>() {
        new Itemlist { Text = "Network Monitoring and Reporting", Value = "Network Monitoring and Reporting" },

        };
            Dropdown08 = new List<Itemlist>() {
        new Itemlist { Text = "Testing Environment Replication", Value = "Testing Environment Replication" },

        };

            Dropdown09 = new List<Itemlist>() {
        new Itemlist { Text = "Network Simulation and Virtualization", Value = "Network Simulation and Virtualization" },

        };

            Dropdown10 = new List<Itemlist>() {
        new Itemlist { Text = "Continuous Optimization", Value = "Continuous Optimization" },

        };
            Dropdown11 = new List<Itemlist>() {
        new Itemlist { Text = "Collaboration with Network Specialists", Value = "Collaboration with Network Specialists" },

        };
            Dropdown2 = new List<Itemlist>() {
        new Itemlist { Text = "High", Value = "High" },
        new Itemlist { Text = "Medium", Value = "Medium" },
        new Itemlist { Text = "Low", Value = "Low" }

        };
            Dropdown3 = new List<Itemlist>() {
        new Itemlist { Text = "Yes", Value = "Yes" },
        new Itemlist { Text = "In Progress", Value = "In Progress" },
        new Itemlist { Text = "No", Value = "No" }

        };
        }
    
        //*************************** Model*****************************
        public int Id { get; set; }
     
        public string Task { get; set; }


       

        public string TaskDone { get; set; }
       
        public string StaffName { get; set; }
        public string LineManager { get; set; }
        public string Priority { get; set; }
        [DataType(DataType.Date)]
        public DateTime DueDate { get; set; }
        [DataType(DataType.Date)]
        public DateTime DateCompleted { get; set; }
        public string Comment { get; set; }

        //****************dropped down list*************************

        [NotMapped]
        public List<Itemlist> Dropdown1 { get; set; }
        [NotMapped]
        public List<Itemlist> Dropdown02 { get; set; }
        [NotMapped]
        public List<Itemlist> Dropdown03 { get; set; }
        [NotMapped]
        public List<Itemlist> Dropdown04 { get; set; }
        [NotMapped]
        public List<Itemlist> Dropdown05 { get; set; }
        [NotMapped]
        public List<Itemlist> Dropdown06 { get; set; }
        [NotMapped]
        public List<Itemlist> Dropdown07 { get; set; }
        [NotMapped]
        public List<Itemlist> Dropdown08 { get; set; }
        [NotMapped]
        public List<Itemlist> Dropdown09 { get; set; }
        [NotMapped]
        public List<Itemlist> Dropdown10 { get; set; }
        [NotMapped]
        public List<Itemlist> Dropdown11 { get; set; }
        [NotMapped]
        public List<Itemlist> Dropdown2 { get; set; }
        [NotMapped]
        public List<Itemlist> Dropdown3 { get; set; }

    }
    [NotMapped]
    public class Itemlist
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }
}
