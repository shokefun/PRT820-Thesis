﻿using System.ComponentModel.DataAnnotations;
using System.Drawing;
using Network_Checklist_Application.Attribute;

namespace Network_Checklist_Application.Models
{
    public class Login
    {
        public int Id { get; set; }
        [Required(ErrorMessage ="Username is required")]
        public string Username { get; set; }
        [Required(ErrorMessage = "password is required")]
        public string Password { get; set; }
        public String? ResetCode { get; set; }
        [GuidAttribute]
        public Guid ActivationCode { get; set; }
        public Login()
        {
            ActivationCode = Guid.NewGuid();
        }

    }
   
}
