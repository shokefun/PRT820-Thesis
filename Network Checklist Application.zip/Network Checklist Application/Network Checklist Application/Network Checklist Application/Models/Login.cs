﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Drawing;
using System.Security.Cryptography;
using System.Text;
using Network_Checklist_Application.Attribute;


namespace Network_Checklist_Application.Models
{
    public class Login
    {
        public int Id { get; set; }
        [Required(ErrorMessage ="Username is required")]

        public string Username { get; set; }
        [NotMapped]
        [Required(ErrorMessage = "Current password is required")]
        [DataType(DataType.Password)]
        public string CurrentPassword { get; set; }
        [NotMapped]
        [Required(ErrorMessage = "New password is required")]
        [DataType(DataType.Password)]
        public string NewPassword { get; set; }
        
        [Required(ErrorMessage = "password is required")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [NotMapped]
        [Required(ErrorMessage = "Confirm Password is required")]
        [DataType(DataType.Password)]
        [Compare(nameof(NewPassword), ErrorMessage ="Password do not match")]
        public string ConfirmPassword { get; set; }
        public String? ResetCode { get; set; }
        [GuidAttribute]
        public Guid ActivationCode { get; set; }
        public Login()
        {
            ActivationCode = Guid.NewGuid();
        }
     
    }
   
}
