﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Network_Checklist_Application.Migrations
{
    /// <inheritdoc />
    public partial class vbf : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
