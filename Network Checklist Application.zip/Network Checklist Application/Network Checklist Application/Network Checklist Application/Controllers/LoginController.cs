﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Network_Checklist_Application.Data;
using Network_Checklist_Application.Migrations;
using Network_Checklist_Application.Models;

using NuGet.Protocol.Plugins;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;

namespace Network_Checklist_Application.Controllers
{
    public class LoginController : Controller
    {


        private readonly Network_Checklist_ApplicationContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public LoginController(Network_Checklist_ApplicationContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }
        [HttpGet]
        public IActionResult Index()


        {
            Login _login = new Login();
            return View(_login);
        }
        [HttpPost]
        public IActionResult Index(Login _login)


        {
            Network_Checklist_ApplicationContext _network_Checklist_ApplicationContext = new Network_Checklist_ApplicationContext();

            var status = _network_Checklist_ApplicationContext.Login.Where(m => m.Username == _login.Username && m.Password == _login.Password).FirstOrDefault();
            if (status == null)
            {
                ViewBag.LoginStatus = 0;



            }
            else
            {
                _httpContextAccessor.HttpContext.Session.SetInt32("UserId", status.Id);
                _httpContextAccessor.HttpContext.Session.SetString("Username", status.Username);
                return RedirectToAction("Index", "Home");
            }
            return View(_login);
        }
        public IActionResult SuccessPage()
        {
            return View();
        }
        [HttpGet]
        public IActionResult PasswordResetPage()


        {
            Login _login = new Login();
            return View(_login);
        }

        [HttpPost]
        public IActionResult PasswordResetPage(Login _login)
        {
            Network_Checklist_ApplicationContext _network_Checklist_ApplicationContext = new Network_Checklist_ApplicationContext();
            var reseted = _network_Checklist_ApplicationContext.Login.Where(m => m.Username == _login.Username).FirstOrDefault();
            if (reseted == null)
            {
                ViewBag.LoginStatus = 0;



            }
            else
            {
                string resetCode = Guid.NewGuid().ToString();
                SendVerificationLink(_login);
                return RedirectToAction("SuccessPage", "Login");
            }
            return View(_login);
        }
        [NonAction]
        public void SendVerificationLink(Login _login)
        {

            Network_Checklist_ApplicationContext _network_Checklist_ApplicationContext = new Network_Checklist_ApplicationContext();
            var ForgottenPassword = _network_Checklist_ApplicationContext.Login.Where(m => m.Username == _login.Username).Select(m => m.Password).FirstOrDefault();




            var fromEmail = new MailAddress("shokefunolumide@gmail.com", "Checklist App");
            var toEmail = new MailAddress(_login.Username);
            var fromEmailPassword = "vkfk exsx tvjf vjnr";
            string subject = "Password Reset";
            string body = "<br/><br> Please find below your requested forgotten password" + $"<br/><br> Your Password Is:{ForgottenPassword}";
            var smtp = new SmtpClient
            {
                Host = "smtp.gmail.com",
                Port = 587,
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(fromEmail.Address, fromEmailPassword)
            };
            using (var message = new MailMessage(fromEmail, toEmail)
            {
                Subject = subject,
                Body = body,
                IsBodyHtml = true,

            })
                smtp.Send(message);
        }

        public IActionResult SubmitPage()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SubmitPage(Login _login)
        {

            Network_Checklist_ApplicationContext _network_Checklist_ApplicationContext = new Network_Checklist_ApplicationContext();
            var status = _network_Checklist_ApplicationContext.Login.Where(m => m.Username == _login.Username && m.Password == _login.Password).FirstOrDefault();
            if (status == null)
            {

                _network_Checklist_ApplicationContext.Login.Add(_login);
                _network_Checklist_ApplicationContext.SaveChangesAsync();
                return RedirectToAction("Index", "Login");
            }
            else
            {
                ViewBag.LoginStatus = 0;
                return View();
            }
        }


        public IActionResult LinkPasswordReset()
        {
            return View();
        }

        [HttpGet]
        public IActionResult ChangePassword()
        {
            return View();
        }
        [HttpPost]
        public IActionResult ChangePassword(Login _login)
        {
            Network_Checklist_ApplicationContext _network_Checklist_ApplicationContext = new Network_Checklist_ApplicationContext();
            int? userId = HttpContext.Session.GetInt32("UserId");
            var user = _network_Checklist_ApplicationContext.Login.Find(userId);
            if (user.Password == _login.CurrentPassword)
            {
                user.Password = _login.NewPassword;
                _network_Checklist_ApplicationContext.Update(user);
                _network_Checklist_ApplicationContext.SaveChangesAsync();
                return RedirectToAction("ChangePasswordSuccess", "Login");

            }
            else
            {
                ViewBag.ResetStatus = 0;
                return View();
            }

           
        }
        [HttpGet]
        public IActionResult ChangePasswordSuccess()
        {
            return View();
        }
        }
}
