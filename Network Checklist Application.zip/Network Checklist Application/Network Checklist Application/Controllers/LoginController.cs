﻿using Microsoft.AspNetCore.Mvc;
using Network_Checklist_Application.Data;
using Network_Checklist_Application.Models;

namespace Network_Checklist_Application.Controllers
{
    public class LoginController : Controller
    {
       
        
            private readonly ILogger<LoginController> _logger;

            public LoginController(ILogger<LoginController> logger)
            {
                _logger = logger;
            }
        [HttpGet]
            public IActionResult Index()
            
           
        {
            Login _login = new Login();
            return View(_login);
        }
        [HttpPost]
        public IActionResult Index(Login _login)


        {
            Network_Checklist_ApplicationContext _network_Checklist_ApplicationContext = new Network_Checklist_ApplicationContext();
            var status =_network_Checklist_ApplicationContext.Login.Where(m=>m.Username == _login.Username && m.Password==_login.Password).FirstOrDefault();
            if (status == null)
            {
                ViewBag.LoginStatus = 0;



            }
            else
            {
              return RedirectToAction("Index", "Checklists");
            }
            return View(_login);
        }
        public IActionResult SuccessPage()
        {
            return View();
        }
        [HttpGet]
        public IActionResult PasswordResetPage()


        {
            Login _login = new Login();
            return View(_login);
        }

        [HttpPost]
        public IActionResult PasswordResetPage(Login _login)
        {
            Network_Checklist_ApplicationContext _network_Checklist_ApplicationContext = new Network_Checklist_ApplicationContext();
            var reseted = _network_Checklist_ApplicationContext.Login.Where(m => m.Username == _login.Username ).FirstOrDefault();
            if (reseted == null)
            {
                ViewBag.LoginStatus = 0;



            }
            else
            {
                return RedirectToAction("Index", "Login");
            }
            return View(_login);
        }
    }
}
