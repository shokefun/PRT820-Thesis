﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Network_Checklist_Application.Data;
using Network_Checklist_Application.Models;
using NuGet.Protocol.Plugins;

namespace Network_Checklist_Application.Controllers
{
    public class ChecklistsController : Controller
    {
        private readonly Network_Checklist_ApplicationContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public ChecklistsController(Network_Checklist_ApplicationContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }
     
        // GET: Checklists
        public async Task<IActionResult> Index()
        {
             
            return _context.Checklist.Where(m => m.Task == "Network Performance Assessment") != null ?
                          View(await _context.Checklist.Where(m => m.Task == "Network Performance Assessment").ToListAsync()) :
                          Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
        }

        // GET: Checklists/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id );
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // GET: Checklists/Create
        public IActionResult Create()
        {
            var model = new Checklist();
            return View(model);
        }

        // POST: Checklists/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (ModelState.IsValid)
            {
                _context.Add(checklist);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(checklist);
        }

        // GET: Checklists/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist == null)
            {
                return NotFound();
            }
            return View(checklist);
        }

        // POST: Checklists/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (id != checklist.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(checklist);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ChecklistExists(checklist.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(checklist);
        }

        // GET: Checklists/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // POST: Checklists/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Checklist == null)
            {
                return Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
            }
            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist != null)
            {
                _context.Checklist.Remove(checklist);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ChecklistExists(int id)
        {
          return (_context.Checklist?.Any(e => e.Id == id)).GetValueOrDefault();
        }
        //****************************************Checklist 2 Codes*****************************************
        // GET: Checklists
        public async Task<IActionResult> Index2()
        {
            return _context.Checklist.Where(m => m.Task == "Network Performance Assessment") != null ?
                      View(await _context.Checklist.Where(m => m.Task == "Data Transfer Optimization").ToListAsync()) :
                      Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
        }

        // GET: Checklists/Details/5
        public async Task<IActionResult> Details2(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // GET: Checklists/Create
        public IActionResult Create2()
        {
            var model = new Checklist();
            return View(model);
        }

        // POST: Checklists/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create2([Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (ModelState.IsValid)
            {
                _context.Add(checklist);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index2));
            }
            return View(checklist);
        }

        // GET: Checklists/Edit/5
        public async Task<IActionResult> Edit2(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist == null)
            {
                return NotFound();
            }
            return View(checklist);
        }

        // POST: Checklists/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit2(int id, [Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (id != checklist.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(checklist);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ChecklistExists2(checklist.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index2));
            }
            return View(checklist);
        }

        // GET: Checklists/Delete/5
        public async Task<IActionResult> Delete2(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // POST: Checklists/Delete/5
        [HttpPost, ActionName("Delete2")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed2(int id)
        {
            if (_context.Checklist == null)
            {
                return Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
            }
            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist != null)
            {
                _context.Checklist.Remove(checklist);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index2));
        }

        private bool ChecklistExists2(int id)
        {
            return (_context.Checklist?.Any(e => e.Id == id)).GetValueOrDefault();
        }
        //****************************************Checklist 3 Codes*****************************************
        // GET: Checklists
        public async Task<IActionResult> Index3()
        {
            return _context.Checklist.Where(m => m.Task == "Redundancy and Failover") != null ?
                      View(await _context.Checklist.Where(m => m.Task == "Redundancy and Failover").ToListAsync()) :
                      Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
        }

        // GET: Checklists/Details/5
        public async Task<IActionResult> Details3(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // GET: Checklists/Create
        public IActionResult Create3()
        {
            var model = new Checklist();
            return View(model);
        }

        // POST: Checklists/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create3([Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (ModelState.IsValid)
            {
                _context.Add(checklist);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index3));
            }
            return View(checklist);
        }

        // GET: Checklists/Edit/5
        public async Task<IActionResult> Edit3(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist == null)
            {
                return NotFound();
            }
            return View(checklist);
        }

        // POST: Checklists/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit3(int id, [Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (id != checklist.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(checklist);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ChecklistExists3(checklist.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index3));
            }
            return View(checklist);
        }

        // GET: Checklists/Delete/5
        public async Task<IActionResult> Delete3(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // POST: Checklists/Delete/5
        [HttpPost, ActionName("Delete3")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed3(int id)
        {
            if (_context.Checklist == null)
            {
                return Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
            }
            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist != null)
            {
                _context.Checklist.Remove(checklist);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index3));
        }

        private bool ChecklistExists3(int id)
        {
            return (_context.Checklist?.Any(e => e.Id == id)).GetValueOrDefault();
        }
        //****************************************Checklist 4 Codes*****************************************
        // GET: Checklists
        public async Task<IActionResult> Index4()
        {
            return _context.Checklist.Where(m => m.Task == "Load Balancing and Scalability") != null ?
                      View(await _context.Checklist.Where(m => m.Task == "Load Balancing and Scalability").ToListAsync()) :
                      Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
        }

        // GET: Checklists/Details/5
        public async Task<IActionResult> Details4(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // GET: Checklists/Create
        public IActionResult Create4()
        {
            var model = new Checklist();
            return View(model);
        }

        // POST: Checklists/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create4([Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (ModelState.IsValid)
            {
                _context.Add(checklist);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index4));
            }
            return View(checklist);
        }

        // GET: Checklists/Edit/5
        public async Task<IActionResult> Edit4(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist == null)
            {
                return NotFound();
            }
            return View(checklist);
        }

        // POST: Checklists/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit4(int id, [Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (id != checklist.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(checklist);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ChecklistExists4(checklist.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index4));
            }
            return View(checklist);
        }

        // GET: Checklists/Delete/5
        public async Task<IActionResult> Delete4(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // POST: Checklists/Delete/5
        [HttpPost, ActionName("Delete4")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed4(int id)
        {
            if (_context.Checklist == null)
            {
                return Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
            }
            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist != null)
            {
                _context.Checklist.Remove(checklist);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index4));
        }

        private bool ChecklistExists4(int id)
        {
            return (_context.Checklist?.Any(e => e.Id == id)).GetValueOrDefault();
        }
        //****************************************Checklist 5 Codes*****************************************
        // GET: Checklists
        public async Task<IActionResult> Index5()
        {
            return _context.Checklist.Where(m => m.Task == "Caching and Content Delivery Networks") != null ?
                      View(await _context.Checklist.Where(m => m.Task == "Caching and Content Delivery Networks").ToListAsync()) :
                      Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
        }

        // GET: Checklists/Details/5
        public async Task<IActionResult> Details5(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // GET: Checklists/Create
        public IActionResult Create5()
        {
            var model = new Checklist();
            return View(model);
        }

        // POST: Checklists/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create5([Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (ModelState.IsValid)
            {
                _context.Add(checklist);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index5));
            }
            return View(checklist);
        }

        // GET: Checklists/Edit/5
        public async Task<IActionResult> Edit5(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist == null)
            {
                return NotFound();
            }
            return View(checklist);
        }

        // POST: Checklists/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit5(int id, [Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (id != checklist.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(checklist);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ChecklistExists5(checklist.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index5));
            }
            return View(checklist);
        }

        // GET: Checklists/Delete/5
        public async Task<IActionResult> Delete5(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // POST: Checklists/Delete/5
        [HttpPost, ActionName("Delete5")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed5(int id)
        {
            if (_context.Checklist == null)
            {
                return Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
            }
            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist != null)
            {
                _context.Checklist.Remove(checklist);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index5));
        }

        private bool ChecklistExists5(int id)
        {
            return (_context.Checklist?.Any(e => e.Id == id)).GetValueOrDefault();
        }
        //****************************************Checklist 6 Codes*****************************************
        // GET: Checklists
        public async Task<IActionResult> Index6()
        {
            return _context.Checklist.Where(m => m.Task == "Network Security") != null ?
                      View(await _context.Checklist.Where(m => m.Task == "Network Security").ToListAsync()) :
                      Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
        }

        // GET: Checklists/Details/5
        public async Task<IActionResult> Details6(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // GET: Checklists/Create
        public IActionResult Create6()
        {
            var model = new Checklist();
            return View(model);
        }

        // POST: Checklists/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create6([Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (ModelState.IsValid)
            {
                _context.Add(checklist);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index6));
            }
            return View(checklist);
        }

        // GET: Checklists/Edit/5
        public async Task<IActionResult> Edit6(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist == null)
            {
                return NotFound();
            }
            return View(checklist);
        }

        // POST: Checklists/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit6(int id, [Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (id != checklist.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(checklist);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ChecklistExists6(checklist.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index6));
            }
            return View(checklist);
        }

        // GET: Checklists/Delete/5
        public async Task<IActionResult> Delete6(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // POST: Checklists/Delete/5
        [HttpPost, ActionName("Delete6")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed6(int id)
        {
            if (_context.Checklist == null)
            {
                return Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
            }
            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist != null)
            {
                _context.Checklist.Remove(checklist);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index6));
        }

        private bool ChecklistExists6(int id)
        {
            return (_context.Checklist?.Any(e => e.Id == id)).GetValueOrDefault();
        }
        //****************************************Checklist 7 Codes*****************************************
        // GET: Checklists
        public async Task<IActionResult> Index7()
        {
            return _context.Checklist.Where(m => m.Task == "Network Monitoring and Reporting") != null ?
                      View(await _context.Checklist.Where(m => m.Task == "Network Monitoring and Reporting").ToListAsync()) :
                      Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
        }

        // GET: Checklists/Details/5
        public async Task<IActionResult> Details7(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // GET: Checklists/Create
        public IActionResult Create7()
        {
            var model = new Checklist();
            return View(model);
        }

        // POST: Checklists/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create7([Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (ModelState.IsValid)
            {
                _context.Add(checklist);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index7));
            }
            return View(checklist);
        }

        // GET: Checklists/Edit/5
        public async Task<IActionResult> Edit7(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist == null)
            {
                return NotFound();
            }
            return View(checklist);
        }

        // POST: Checklists/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit7(int id, [Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (id != checklist.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(checklist);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ChecklistExists7(checklist.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index7));
            }
            return View(checklist);
        }

        // GET: Checklists/Delete/5
        public async Task<IActionResult> Delete7(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // POST: Checklists/Delete/5
        [HttpPost, ActionName("Delete7")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed7(int id)
        {
            if (_context.Checklist == null)
            {
                return Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
            }
            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist != null)
            {
                _context.Checklist.Remove(checklist);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index7));
        }

        private bool ChecklistExists7(int id)
        {
            return (_context.Checklist?.Any(e => e.Id == id)).GetValueOrDefault();
        }
        //****************************************Checklist 8 Codes*****************************************
        // GET: Checklists
        public async Task<IActionResult> Index8()
        {
            return _context.Checklist.Where(m => m.Task == "Testing Environment Replication") != null ?
                      View(await _context.Checklist.Where(m => m.Task == "Testing Environment Replication").ToListAsync()) :
                      Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
        }

        // GET: Checklists/Details/5
        public async Task<IActionResult> Details8(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // GET: Checklists/Create
        public IActionResult Create8()
        {
            var model = new Checklist();
            return View(model);
        }

        // POST: Checklists/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create8([Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (ModelState.IsValid)
            {
                _context.Add(checklist);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index8));
            }
            return View(checklist);
        }

        // GET: Checklists/Edit/5
        public async Task<IActionResult> Edit8(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist == null)
            {
                return NotFound();
            }
            return View(checklist);
        }

        // POST: Checklists/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit8(int id, [Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (id != checklist.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(checklist);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ChecklistExists8(checklist.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index8));
            }
            return View(checklist);
        }

        // GET: Checklists/Delete/5
        public async Task<IActionResult> Delete8(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // POST: Checklists/Delete/5
        [HttpPost, ActionName("Delete8")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed8(int id)
        {
            if (_context.Checklist == null)
            {
                return Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
            }
            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist != null)
            {
                _context.Checklist.Remove(checklist);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index8));
        }

        private bool ChecklistExists8(int id)
        {
            return (_context.Checklist?.Any(e => e.Id == id)).GetValueOrDefault();
        }
        //****************************************Checklist 9 Codes*****************************************
        // GET: Checklists
        public async Task<IActionResult> Index9()
        {
            return _context.Checklist.Where(m => m.Task == "Network Simulation and Virtualization") != null ?
                      View(await _context.Checklist.Where(m => m.Task == "Network Simulation and Virtualization").ToListAsync()) :
                      Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
        }

        // GET: Checklists/Details/5
        public async Task<IActionResult> Details9(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // GET: Checklists/Create
        public IActionResult Create9()
        {
            var model = new Checklist();
            return View(model);
        }

        // POST: Checklists/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create9([Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (ModelState.IsValid)
            {
                _context.Add(checklist);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index9));
            }
            return View(checklist);
        }

        // GET: Checklists/Edit/5
        public async Task<IActionResult> Edit9(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist == null)
            {
                return NotFound();
            }
            return View(checklist);
        }

        // POST: Checklists/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit9(int id, [Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (id != checklist.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(checklist);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ChecklistExists9(checklist.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index9));
            }
            return View(checklist);
        }

        // GET: Checklists/Delete/5
        public async Task<IActionResult> Delete9(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // POST: Checklists/Delete/5
        [HttpPost, ActionName("Delete9")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed9(int id)
        {
            if (_context.Checklist == null)
            {
                return Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
            }
            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist != null)
            {
                _context.Checklist.Remove(checklist);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index9));
        }

        private bool ChecklistExists9(int id)
        {
            return (_context.Checklist?.Any(e => e.Id == id)).GetValueOrDefault();
        }
        //****************************************Checklist 10 Codes*****************************************
        // GET: Checklists
        public async Task<IActionResult> Index10()
        {
            return _context.Checklist.Where(m => m.Task == "Continuous Optimization") != null ?
                      View(await _context.Checklist.Where(m => m.Task == "Continuous Optimization").ToListAsync()) :
                      Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
        }

        // GET: Checklists/Details/5
        public async Task<IActionResult> Details10(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // GET: Checklists/Create
        public IActionResult Create10()
        {
            var model = new Checklist();
            return View(model);
        }

        // POST: Checklists/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create10([Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (ModelState.IsValid)
            {
                _context.Add(checklist);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index10));
            }
            return View(checklist);
        }

        // GET: Checklists/Edit/5
        public async Task<IActionResult> Edit10(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist == null)
            {
                return NotFound();
            }
            return View(checklist);
        }

        // POST: Checklists/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit10(int id, [Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (id != checklist.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(checklist);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ChecklistExists10(checklist.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index10));
            }
            return View(checklist);
        }

        // GET: Checklists/Delete/5
        public async Task<IActionResult> Delete10(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // POST: Checklists/Delete/5
        [HttpPost, ActionName("Delete10")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed10(int id)
        {
            if (_context.Checklist == null)
            {
                return Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
            }
            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist != null)
            {
                _context.Checklist.Remove(checklist);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index10));
        }

        private bool ChecklistExists10(int id)
        {
            return (_context.Checklist?.Any(e => e.Id == id)).GetValueOrDefault();
        }
        //****************************************Checklist 11 Codes*****************************************
        // GET: Checklists
        public async Task<IActionResult> Index11()
        {
            return _context.Checklist.Where(m => m.Task == "Collaboration with Network Specialists") != null ?
                      View(await _context.Checklist.Where(m => m.Task == "Collaboration with Network Specialists").ToListAsync()) :
                      Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
        }

        // GET: Checklists/Details/5
        public async Task<IActionResult> Details11(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // GET: Checklists/Create
        public IActionResult Create11()
        {
            var model = new Checklist();
            return View(model);
        }

        // POST: Checklists/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create11([Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (ModelState.IsValid)
            {
                _context.Add(checklist);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index11));
            }
            return View(checklist);
        }

        // GET: Checklists/Edit/5
        public async Task<IActionResult> Edit11(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist == null)
            {
                return NotFound();
            }
            return View(checklist);
        }

        // POST: Checklists/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit11(int id, [Bind("Id,Task,TaskDone,StaffName,LineManager,Priority,DueDate,DateCompleted,Comment")] Checklist checklist)
        {
            if (id != checklist.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(checklist);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ChecklistExists11(checklist.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index11));
            }
            return View(checklist);
        }

        // GET: Checklists/Delete/5
        public async Task<IActionResult> Delete11(int? id)
        {
            if (id == null || _context.Checklist == null)
            {
                return NotFound();
            }

            var checklist = await _context.Checklist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (checklist == null)
            {
                return NotFound();
            }

            return View(checklist);
        }

        // POST: Checklists/Delete/5
        [HttpPost, ActionName("Delete11")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed11(int id)
        {
            if (_context.Checklist == null)
            {
                return Problem("Entity set 'Network_Checklist_ApplicationContext.Checklist'  is null.");
            }
            var checklist = await _context.Checklist.FindAsync(id);
            if (checklist != null)
            {
                _context.Checklist.Remove(checklist);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index11));
        }

        private bool ChecklistExists11(int id)
        {
            return (_context.Checklist?.Any(e => e.Id == id)).GetValueOrDefault();
        }
        //************************************* Intro Page***********************//
        public IActionResult Intro()
        {
            return View();


        }
        /****************************Documentation *********************************/
        public IActionResult Documentation()
        {
            return View();
        }
        //***************************************dashboard count***********************************

        public IActionResult Dashboard()
        {
            Network_Checklist_ApplicationContext _network_Checklist_ApplicationContext = new Network_Checklist_ApplicationContext();
            int dash1 = _network_Checklist_ApplicationContext.Checklist.Count(m => m.Task == "Network Performance Assessment");
            int dash2 = _network_Checklist_ApplicationContext.Checklist.Count(m => m.Task == "Data Transfer Optimization");
            int dash3 = _network_Checklist_ApplicationContext.Checklist.Count(m => m.Task == "Redundancy and Failover");
            int dash4 = _network_Checklist_ApplicationContext.Checklist.Count(m => m.Task == "Load Balancing and Scalability");
            int dash5 = _network_Checklist_ApplicationContext.Checklist.Count(m => m.Task == "Caching and Content Delivery Networks");
            int dash6 = _network_Checklist_ApplicationContext.Checklist.Count(m => m.Task == "Network Security");
            int dash7 = _network_Checklist_ApplicationContext.Checklist.Count(m => m.Task == "Network Monitoring and Reporting");
            int dash8 = _network_Checklist_ApplicationContext.Checklist.Count(m => m.Task == "Testing Environment Replication");
            int dash9 = _network_Checklist_ApplicationContext.Checklist.Count(m => m.Task == "Network Simulation and Virtualization");
            int dash10 = _network_Checklist_ApplicationContext.Checklist.Count(m => m.Task == "Continuous Optimization");
            int dash11 = _network_Checklist_ApplicationContext.Checklist.Count(m => m.Task == "Collaboration with Network Specialists");
            ViewBag.dashboard1 = dash1;
            ViewBag.dashboard2 = dash2;
            ViewBag.dashboard3 = dash3;
            ViewBag.dashboard4 = dash4;
            ViewBag.dashboard5 = dash5;
            ViewBag.dashboard6 = dash6;
            ViewBag.dashboard7 = dash7;
            ViewBag.dashboard8 = dash8;
            ViewBag.dashboard9 = dash9;
            ViewBag.dashboard10 = dash10;
            ViewBag.dashboard11 = dash11;

            return View();
            
           
        }
    }

}
